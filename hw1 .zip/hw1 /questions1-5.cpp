/* Priska Mohunsingh
* HW 1: Questions 1-5
* Due Date: Feb. 9, 2018
*/
 
#include <iostream>

using namespace std;
 
void rotate(int arr[], int d, int n);
void maxProfit(int prices[], int size);
void pushZerosToEnd(int arr[], int n);
void mergeArrays(int arr1[], int arr2[], int n1, int n2, int arr3[]);
void findMajority(int arr[], int size);

int main()
{
   int arr[20], d , n ;
   cout << "--Test for rotate--: " << endl;
   cout << "Enter n: ";
   cin >> n;
   cout << "Enter d: ";
   cin >> d;
   cout << "Enter " << n << " elements: ";
   for (int i = 0; i < n; i++)
   {
     cin >> arr[i];
   }
   rotate(arr, d, n);
   cout << "After rotation: ";
   for (int i = 0; i < n; i++)
   {
     cout << arr[i] << " ";
   }
   cout << endl<<endl;

   cout << "--Test for maxProfit--: " << endl;
   int prices[20];
   cout << "Enter how many prices you want to enter(n): ";
   cin >> n;
   cout << "Enter " << n << " prices: ";
   for (int i = 0; i < n; i++)
   {
     cin >> prices[i];
   }
     maxProfit(prices, n);
   cout << endl<<endl;

   cout << "--Test for pushZerosToEnd--: " << endl;
   int arr1[20];
   cout << "Enter how many numbers you want to enter(n): ";
   cin >> n;
   cout << "Enter " << n << " numbers including zeros: ";
    for (int i = 0; i < n; i++)
    {
     cin >> arr1[i];
   }
   pushZerosToEnd(arr1, n);
   cout << "After pushing zeros to end: ";
   for (int i = 0; i < n; i++)
   {
     cout << arr1[i] << " ";
   }
   cout << endl << endl;
 
   cout << "--Test for mergeArrays--: " << endl;
   int a1[20], a2[20], a3[40], n1, n2, n3;
   cout << "Enter how many numbers you want to enter into first array(n1): ";
   cin >> n1;
   cout << "Enter how many number you want to enter into second array(n2): ";
   cin >> n2;
   n3 = n1 + n2;
   cout << "Enter " << n1 << " numbers: ";
   for (int i = 0; i < n1; i++)
   {
     cin >> a1[i];
   }
   cout << "Enter " << n2 << " numbers: ";
   for (int i = 0; i < n2; i++)
   {
     cin >> a2[i];
   }
   mergeArrays(a1, a2, n1, n2, a3);
   cout << "Merged array 3: ";
   for (int i = 0; i < n3; i++)
   {
     cout << a3[i] << " ";
   }
   cout << endl << endl;
  
   cout << "--Test for findMajority--: " << endl;
   int arr4[20];
   cout << "Enter how many numbers you want to enter (n): ";
   cin >> n;
   cout << "Enter " << n << " numbers: ";
   for (int i = 0; i < n; i++)
   {
     cin >> arr4[i];
   }
   findMajority(arr4,n);
   return 0;
 }

 void rotate(int arr[], int d, int n)
 {
   while (d > 0)
   {
     int last = arr[0];
     for (int i = 1; i < n; i++)
     {
       arr[i - 1] = arr[i];
     }
     arr[n - 1] = last;
     d--;
   }
}
 
 void maxProfit(int prices[], int size)
 {
   int max = 0;
   for (int i = 0; i < size; i++)
   {
     for (int j = i+1; j < size-1; j++)
     {
       if ( (prices[j] - prices[i]) > max)
       {
          max = prices[j] - prices[i];
       }
     }
  }
   cout << "Maximum profit: " << max << endl;
 }
 
void pushZerosToEnd(int arr[], int n)
{
  for (int i = 0; i < n; i++)
  {
     if (arr[i] == 0)
     {
       for (int j = i; j < n-1; j++)
       {
         arr[j] = arr[j + 1];
       }
       arr[n - 1] = 0;
     }
   }
}
 
void mergeArrays(int arr1[], int arr2[], int n1, int n2, int arr3[])
{
  int i, j, k;
  int n = n1 + n2;
  for (i = 0; i < n1; i++)
  {
    for (j = 0; j < n1; j++)
    {
      if (arr1[i] < arr1[j])
      {
        int temp = arr1[i];
        arr1[i] = arr1[j];
        arr1[j] = temp;
      }
    }
  }

 for (i = 0; i < n2; i++)
 {
    for (j = 0; j < n2; j++)
    {
      if (arr2[i] < arr2[j])
      {
        int temp = arr2[i];
        arr2[i] = arr2[j];
        arr2[j] = temp;
      }
    }
 }

 i = 0, j = 0, k = 0;
 while (i < n1 && j < n2)
 {
   if (arr1[i] < arr2[j])
   {
      arr3[k] = arr1[i];
      k++;
      i++;
   }
   else
   {
      arr3[k] = arr2[j];
      k++;
      j++;
   }
 }
 while (i < n1)
 {
   arr3[k] = arr1[i];
   k++;
   i++;
 }
 while (j < n2)
 {
   arr3[k] = arr2[j];
   k++;
   j++;
 }
}

void findMajority(int arr[], int size)
{
  int halfSize = size / 2;
  int count = 0;
  for (int i = 0; i < size; i++)
  {
    count = 0;
    for (int j = i; j < size; j++)
    {
       if (arr[i] == arr[j])
       {
         count++;
       }
    }
    if (count >= halfSize)
    {
       cout << arr[i] << " is the majority element" << endl;
       break;
    }
  }
}